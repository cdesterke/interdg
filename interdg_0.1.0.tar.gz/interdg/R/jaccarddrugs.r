#' @title jaccarddrugs

#' @param custom your custom gene set
#' @param res results from computedrugs performed on custom
#' @param nb number of drugs to display
#' @param xmarg margin size in X
#' @param ymarg margin size in Y
#' @usage jaccarddrugs(custom,res,nb=10,xmarg=12,ymarg=12)
#' @examples data(custom)
#' @examples res<-computedrugs(custom)
#' @examples df<-jaccarddrugs(custom,res,nb=10,xmarg=12,ymarg=12)
#' @examples ## save results in "druginteractions.tsv" file

jaccarddrugs<-function(custom,res,nb=10,xmarg=12,ymarg=12){

	if(!require(plyr)){
    		install.packages("plyr")
    		library(plyr)}


	data(listdrugs)

	inter<-list()

	for(i in 1:length(listdrugs)){
		inter[[i]]<-intersect(custom,names(listdrugs[[i]]))}


	names(inter)<-names(listdrugs)

	inter<-lapply(inter, function(z){ z[!is.na(z) & z != "NA"]})
	inter<-inter[lapply(inter,length)>0]

	## subset list intersection with selected drugs

	sig=head(res$drug_name,n=nb)
	intersig<-inter[sig]

	result <- sapply(intersig,function(x)
            sapply(intersig,function(y,x)length(intersect(x,y))/length(union(x,y)),x))

	result<-as.matrix(result)
	heatmap(result,margins = c(xmarg, ymarg),cexRow=1,cexCol=1)

	df <- ldply (intersig, data.frame)
	colnames(df)<-c("DRUGS","GENES")
	write.table(df,file="drugsinteractions.tsv",sep="\t",row.names=F)
	df


}


