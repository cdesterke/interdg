#' @title geneqvectordg

#' @param res limma results
#' @param q q-value threshold for filtration of limma results
#' @param updown string up or down to select direction of filtration 
#' @param thres absolute value of logFC threshold for filtration
#' @usage custom<-geneqvectordg(res, q=0.05, updown="up", thres=0.5)
#' @examples custom<-geneqvectordg(res, q=0.05, updown="up", thres=0.5)



geneqvectordg<-function(limma, q = 0.05,updown="up",thres=0.5){
  	if(!require(dplyr)){
    	install.packages("dplyr")
    	library(dplyr)}

limma%>%filter(adj.P.Val < q)->df

	if (updown == "up"){
	df%>%filter(logFC > thres)->final
	}
	else if (updown == "down"){
	df%>%filter(logFC < -thres)->final
	}

	return(row.names(final))
}
