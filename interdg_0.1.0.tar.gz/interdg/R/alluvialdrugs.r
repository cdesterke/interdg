#' @title alluvialdrugs

#' @param df output of jaccarddrugs
#' @usage alluvialdrugs(df,font=18)
#' @examples data(custom)
#' @examples res<-computedrugs(custom)
#' @examples df<-jaccarddrugs(custom,res,nb=10,xmarg=12,ymarg=12)
#' @examples alluvialdrugs(df,font=18)




alluvialdrugs<-function(df,font=18){

	if(!require(ggplot2)){
    		install.packages("ggplot2")
    		library(ggplot2)}

	if(!require(pals)){
    		install.packages("pals")
    		library(pals)}


	if(!require(ggalluvial)){
    		install.packages("ggalluvial")
    		library(ggalluvial)}

	df$count<-1

	ggplot(as.data.frame(df),
       	aes(y = count, axis1 = DRUGS, axis2 = GENES)) +
	geom_alluvium(aes(fill = DRUGS), width = 1/12) +
  	geom_stratum(width = 1/12, fill = "white", color = "grey") +
  	geom_label(stat = "stratum", aes(label = after_stat(stratum)))+theme_minimal()+
 	scale_x_discrete(limits = c("DRUGS", "GENES"),expand = c(.05, .05))+
  	scale_fill_manual(values=cols25())+theme(text = element_text(size = font))+xlab("")+ylab("")

}
