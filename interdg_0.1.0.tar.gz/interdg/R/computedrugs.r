#' @title computedrugs

#' @param custom input custom vector of genes to make enrichment
#' @usage res<-computedrugs(custom)
#' @examples res<-computedrugs(custom)
#' @examples ## results will be saved in "drugsresults.tsv" file



computedrugs<-function(custom){

	data(large)
	data(listdrugs)
	data(interactions)

	drugs <- large$drug_name
	drugs <- as.data.frame(drugs)

	for(i in 1:length(listdrugs)){
		drugs$intersect[i]<-length(base::intersect(custom,names(listdrugs[[i]])))}

	drugs$input<-length(custom)

	for(i in 1:length(listdrugs)){
		drugs$perturbagens[i]<-length(names(listdrugs[[i]]))}

	drugs$totaldb<-length(base::unique(unlist(names(listdrugs))))




	row.names(drugs)<-drugs$drugs
	drugs$drugs<-NULL
  df<-drugs
	df<-df[(df$intersect != "0"),]
	df<-df[with(df,order(-intersect)),]

	res1 <- NULL
	for (i in 1:nrow(df)){
 		table <- matrix(c(df[i,1], df[i,2], df[i,3], df[i,4]), ncol = 2, byrow = TRUE)
  		o <- fisher.test(table, alternative="two.sided")$estimate
  		# save all odds in a vector
  		res1 <- c(res1,o)
		}
	df$ES <- res1



	res2 <- NULL
	for (i in 1:nrow(df)){
  		table <- matrix(c(df[i,1], df[i,2], df[i,3], df[i,4]), ncol = 2, byrow = TRUE)
  	p <- fisher.test(table, alternative="two.sided")$p.value
  	# save all p values in a vector
  	res2 <- c(res2,p)
	}
	df$pvalues <- res2


	df$qvalues<-p.adjust(df$pvalues,method="fdr")
	df<-df[with(df,order(qvalues)),]
	df2<-df[(df$intersect > 1),]

	##annotations (84 classes interactions)
	if(!require(dplyr)){
	  install.packages("dplyr")
	  library(dplyr)}

	interactions%>%distinct(drug_name,.keep_all=T)->interactions
	df2$drug_name<-row.names(df2)

	interactions%>%right_join(df2,by="drug_name")->df2
	df2$interaction_types[is.na(df2$interaction_types)] <- "undefined"

	df2<-df2[with(df2,order(pvalues)),]
	write.table(df2,file="drugsresults.tsv",sep="\t",row.names=F)
	df2
}




