#' @title plotdrugs

#' @param res results from computedrugs
#' @param n number of drugs to plot
#' @param font size of the font in the graph
#' @param label size of labels ES scores in front of the bars
#' @usage plotdrugs(res,n=10,font=16,label=4)
#' @examples plotdrugs(res,n=10,font=16,label=4)


plotdrugs<-function(res,n=15,font=16,label=4){

	if(!require(ggplot2)){
    		install.packages("ggplot2")
    		library(ggplot2)}
	if(!require(pals)){
    		install.packages("pals")
    		library(pals)}

	p=ggplot(data=(head(res,n=n)),aes(x=reorder(drug_name,-log(pvalues)),y=-log(pvalues),fill=interaction_types))+
	geom_bar(stat="identity")+coord_flip()+theme_minimal()

	p +  xlab("Drugs") + ylab("Enrichment score")

	p + scale_fill_manual(values=cols25())+
	geom_text(aes(label=round(ES,2)),hjust=0, vjust=0.5,color="black",position= position_dodge(0),size=label,angle=0)+
	xlab("Drugs") + ylab("Enrichment score")+
	ggtitle("Enriched Drugs") +theme(text = element_text(size = font))

}
